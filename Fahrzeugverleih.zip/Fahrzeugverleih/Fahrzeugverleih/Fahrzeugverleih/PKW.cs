﻿namespace Fahrzeugverleih
{
    enum Treibstoffart
    {
        benzin, diesel
    }
    enum Schaltung
    {
        Automatik, Handschaltung
    }
    class PKW : Kraftfahrzeug
    {

        public Treibstoffart treibstoffart { get; private set; }

        public Schaltung schaltung { get; private set; }

        private decimal treibstofffaktor;

        public decimal Treibstofffaktor
        {
            get { return treibstofffaktor; }
            set
            {

                if (schaltung == Schaltung.Automatik)
                {
                    if (treibstoffart == Treibstoffart.benzin)
                    {
                        treibstofffaktor = ((decimal)1.15) * (decimal)1.5;
                    }
                    else
                    {
                        treibstofffaktor = ((decimal)1) * (decimal)1.5;
                    }
                }
                else
                {
                    if (treibstoffart == Treibstoffart.benzin)
                    {
                        treibstofffaktor = (decimal)1.15;
                    }
                    else
                    {
                        treibstofffaktor = 1;
                    }
                }

            }
        }



        public override decimal Mietpreis(decimal mietdauer)
        {
            return base.Mietpreis(mietdauer) * Preis * Treibstofffaktor * PsFaktor;
        }

        public PKW(string kennzeichen, string bezeichnung, Fahrzeuge fahrzeuga, decimal ps, Treibstoffart treibstoffart, Schaltung schaltung)
           : base(kennzeichen, bezeichnung, fahrzeuga, ps)
        {
            this.treibstoffart = treibstoffart;
            this.schaltung = schaltung;
        }

        public void ErhöhePreis(decimal prozent)
        {
            Preis *= prozent;
        }
        public override string ToString()
        {
            return base.ToString() + $"Treibstoffart: {treibstoffart} Schaltung: {schaltung}";
        }
    }
}
