﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrzeugverleih
{
    enum Fahrzeuge
    {
        PKW, LKW, Fahrrad
    }
     class Fahrzeug
    {

        public string Kennzeichen { get; set; }

        public string Bezeichnung { get; private set; }

        public Fahrzeuge fahrzeug { get; private set; }

       
        public virtual decimal Mietpreis(decimal mietdauer)
        {
            decimal mietpreis = mietdauer;
            return mietpreis;

        }

        public Fahrzeug(string kennzeichen, string bezeichnung, Fahrzeuge fahrzeuga)
        {
            Kennzeichen = kennzeichen;
            Bezeichnung  = bezeichnung;
            fahrzeug = fahrzeuga;

        }

        protected decimal preis;

        protected decimal Preis
        {
            get { return preis; }
            set
            {
                if ( fahrzeug == Fahrzeuge.LKW )
                {
                    preis = 110; 
                }
                else
                {
                    if (fahrzeug== Fahrzeuge.Fahrrad)
                    {
                        preis = 1.50m;
                    }
                    else
                    {
                        if (fahrzeug == Fahrzeuge.PKW)
                        {
                            preis = 7;
                        }
                    }

                }
                preis = value;
            }
        }


        public override string ToString()
        {
            return $"kennzeichen = {Kennzeichen} bezeichnung: {Bezeichnung} Fahrzeug: {fahrzeug}";
        }
    }
}
