﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrzeugverleih
{
    class Container
    {
        
        public List<Vermietung> vermietungen = new List<Vermietung>();

        public void Add(Vermietung v )
        {

            vermietungen.Add(v);

        }


        public override string ToString()
        {
            StringBuilder buil = new StringBuilder();
            buil.AppendLine("Alle Vermietungen:");
            foreach (var item in vermietungen)
            {
                buil.Append(item.ToString());

            }
            return buil.ToString();
        }

        

    }
}
