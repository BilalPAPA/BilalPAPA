﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrzeugverleih
{
    enum Bauart
    {
        kipper,
        Sattelzugmaschine
    }
    class LKW : Kraftfahrzeug
    {
        public Bauart bauart { get; private set; }

        private bool mitohne;

        public bool Mitohne
        {
            get { return mitohne; }
            set
            {
                if (bauart == Bauart.Sattelzugmaschine)
                {
                    mitohne = value;
                }
                else
                {
                    mitohne = false;
                }
            }
        }

        public LKW(string kennzeichen, string bezeichnung, Fahrzeuge fahrzeuga, decimal ps, Bauart bauart, bool mitohne)
            : base(kennzeichen, bezeichnung, fahrzeuga, ps)
        {
            this.bauart = bauart;
            this.Mitohne = mitohne; 
        }

        public override decimal Mietpreis(decimal mietdauer)
        {
            decimal bauartfaktor = 0; 
            if ( bauart == Bauart.kipper)
            {
                bauartfaktor = (decimal)1.25;
                if (mitohne == true)
                    bauartfaktor += 20;
            }
            return base.Mietpreis(mietdauer) * Preis * bauartfaktor * PsFaktor;
        }


        public void ErhöhePreis(decimal prozent)
        {
            Preis *= prozent;
        }

        public override string ToString()
        {
            return base.ToString()+$"Bauart: {bauart} Mitohne: {Mitohne}";
        }
    }
}
