﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrzeugverleih
{
    class Vermietung
    {
        public decimal Mietdauer { get; private set; }

        private Fahrzeug fahrzeug;

        public Fahrzeug Fahrzeug 
        {
            get { return fahrzeug; }
            set { fahrzeug = value; }
        }

        public decimal MietPreis { get; private set; }

        public Vermietung(decimal mietdauer, Fahrzeug fahrzeug)
        {
            Mietdauer = mietdauer;
            MietPreis = fahrzeug.Mietpreis(mietdauer);
            Fahrzeug = fahrzeug;
        }

        public override string ToString()
        {
            
            return $"{ Fahrzeug.ToString()} MietPreis : {MietPreis} Mietdauer :{Mietdauer} ";
        }
    }
}
