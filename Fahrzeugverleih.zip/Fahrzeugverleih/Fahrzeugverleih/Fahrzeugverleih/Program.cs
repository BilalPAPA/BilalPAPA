﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrzeugverleih
{
    class Program
    {
        static void Main(string[] args)
        {
            //PKW pkw1 = new PKW("1233", "Opel", Fahrzeuge.PKW,500, Treibstoffart.benzin, Schaltung.Automatik);
            //PKW pkw2 = new PKW("Mercedes", "3321", Fahrzeuge.PKW,220, Treibstoffart.diesel, Schaltung.Handschaltung);
            //LKW lkw1 = new LKW("SLSF", "Bugstti",Fahrzeuge.LKW, 450, Bauart.kipper, false);
            //LKW lkw2 = new LKW("EFB", "LOLDD", Fahrzeuge.LKW ,720, Bauart.Sattelzugmaschine, true);
            //LKW lkw3 = new LKW("KA12", "Bugatti",Fahrzeuge.LKW, 500, Bauart.Sattelzugmaschine, false);
            //Fahrrad fahrrad1 = new Fahrrad("Berlin22139", "KTM",Fahrzeuge.Fahrrad, Typ.Trekkingrad, true, true);
            //Fahrrad fahrrad2 = new Fahrrad("KTTK", "KAMAN", Fahrzeuge.Fahrrad, Typ.Mountainbike, false, true);


            PKW pkw1 = new PKW("Axyz0", "Bmw 320d ", Fahrzeuge.PKW, 120, Treibstoffart.benzin, Schaltung.Automatik);
            PKW pkw2 = new PKW("Axyz023", "Bmw m5 ", Fahrzeuge.PKW, 220, Treibstoffart.diesel, Schaltung.Handschaltung);

            LKW lkw1 = new LKW("Honey", "MAN", Fahrzeuge.LKW, 450, Bauart.kipper, false);
            LKW lkw2 = new LKW("MOney", "Mercedes Benz", Fahrzeuge.LKW, 720, Bauart.Sattelzugmaschine, true);
            LKW lkw3 = new LKW("Loneey", "Scania", Fahrzeuge.LKW, 500, Bauart.Sattelzugmaschine, false);

            Fahrrad fahrrad = new Fahrrad("programmierer", "Mansheim", Fahrzeuge.Fahrrad, Typ.Trekkingrad, true, true);
            Fahrrad fahrrad2 = new Fahrrad("Java", "landsheim", Fahrzeuge.Fahrrad, Typ.Mountainbike, true, false);
            Fahrrad fahrrad3 = new Fahrrad("C#", "wandsheim", Fahrzeuge.Fahrrad, Typ.Rennrad, false, false);

            Vermietung vermietung1 = new Vermietung(8, pkw1);
            Vermietung vermietung2 = new Vermietung(6.5m, pkw2);
            Vermietung vermietung3 = new Vermietung(72, lkw1);
            Vermietung vermietung4 = new Vermietung(120, lkw2);
            Vermietung vermietung5 = new Vermietung(48, lkw3);
            Vermietung vermietung6 = new Vermietung(4, fahrrad);
            Vermietung vermietung7 = new Vermietung(3.5m, fahrrad2);
            Vermietung vermietung8 = new Vermietung(5, fahrrad3);

            Console.WriteLine( vermietung1.ToString());
            Console.WriteLine(vermietung2);
            Console.WriteLine(vermietung3);
            Console.WriteLine(vermietung4);
            Console.WriteLine(vermietung5);
            Console.WriteLine(vermietung6);
            Console.WriteLine(vermietung7);
            Console.WriteLine(vermietung8);

            Console.WriteLine();


            lkw1.ErhöhePreis(15);
            lkw2.ErhöhePreis(15);
            lkw3.ErhöhePreis(15);

            Vermietung vermietung9 = new Vermietung(72, lkw1);
            Vermietung vermietung10 = new Vermietung(120, lkw2);
            Vermietung vermietung11 = new Vermietung(48, lkw3);


            Console.WriteLine(vermietung9);
            Console.WriteLine(vermietung10);
            Console.WriteLine(vermietung11);

            Console.ReadKey();
        }
    }
}
