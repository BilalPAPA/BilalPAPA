﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrzeugverleih
{
    class Kraftfahrzeug:Fahrzeug
    {
        public decimal PS { get; private set; }

        public decimal psfaktor;

        public decimal PsFaktor
        {
            get { return psfaktor; }
            set
            {
                if (PS < 200)
                {
                    psfaktor = 1;
                }
                else
                {
                    if (PS >= 200 && PS<= 500)
                    {
                        psfaktor = (PS - 200) / 500 + 1;

                    }
                    else
                    {
                        if (PS > 500)
                        {
                            psfaktor = (decimal)1.6;
                        }
                    }
                }
                
            }
        }


        public Kraftfahrzeug(string kennzeichen, string bezeichnung, Fahrzeuge fahrzeuga, decimal ps)
            :base (kennzeichen, bezeichnung, fahrzeuga)
        {
            this.PS = ps; 
        }
        

        public override string ToString()
        {
            return base.ToString()+$"PS: {PS}";
        }
    }
}
