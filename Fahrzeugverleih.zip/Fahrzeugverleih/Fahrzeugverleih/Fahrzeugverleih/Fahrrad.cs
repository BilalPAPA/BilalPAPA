﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fahrzeugverleih
{
    enum Typ
    {
        Trekkingrad, 
        Mountainbike, 
        Rennrad

    }

    class Fahrrad:Fahrzeug
    {
        public Typ Typ { get; private set; }

        public bool Helm { get; set; }

        private bool gepäcksanhänger;

        public bool Gepäcksanhänger
        {
            get { return gepäcksanhänger; }
            set
            {
                if (Typ == Typ.Mountainbike || Typ == Typ.Mountainbike)
                {
                    gepäcksanhänger = value;
                }
                else
                {
                    gepäcksanhänger = false;
                }
            }
        }

        public Fahrrad(string kennzeichen, string bezeichnung, Fahrzeuge fahrzeuga, Typ typ , bool helm, bool gepäcksanhänger) 
            : base(kennzeichen, bezeichnung, fahrzeuga)
        {
            Typ = typ;
            Helm = helm;
            Gepäcksanhänger = gepäcksanhänger;
        }

       
        public override decimal Mietpreis(decimal mietdauer)
        {
            decimal mietpreis=0;
            if (Typ == Typ.Mountainbike)
            {
                mietpreis = base.Mietpreis(mietdauer) * Preis;
            }
            else
            {
                if (Typ == Typ.Rennrad)
                {
                    mietpreis = (base.Mietpreis(mietdauer) * Preis)+2;
                }
                else
                {
                    if (Typ == Typ.Trekkingrad)
                    {
                        mietpreis = (base.Mietpreis(mietdauer) * Preis) + 1;
                    }
                }
            }

            if ( Gepäcksanhänger == true)
            {
                mietpreis += 10;
            }

            if (Helm == true)
            {
                mietpreis += 3; 

            }
            
            return mietpreis;
        }

        public void ErhöhePreis(decimal prozent)
        {
            Preis *= prozent;
        }

        public override string ToString()
        {
            return base.ToString()+ $"Typ: {Typ} Gepäcksanhänger: {Gepäcksanhänger} Helm: {Helm}";
        }
    }
}
