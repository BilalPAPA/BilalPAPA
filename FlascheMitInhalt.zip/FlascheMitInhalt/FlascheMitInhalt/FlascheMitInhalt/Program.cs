﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlascheMitInhalt
{
    class Program
    {
        static void Main(string[] args)
        {
            Beer bierflüssigkeit = new Beer("OttakringerBrauerei");
            Bottle Bier = new Bottle(bierflüssigkeit, 1000, Volume._2000);
            Console.WriteLine(Bier.ToString());
            Console.ReadKey();
        }
    }
}
