﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlascheMitInhalt
{
    class RedWine : Wine
    {
        public RedWine(string region) 
            : base(region)
        {
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
