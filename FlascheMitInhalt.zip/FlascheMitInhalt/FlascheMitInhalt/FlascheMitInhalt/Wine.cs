﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlascheMitInhalt
{
    abstract class Wine : Liquid
    {
        public bool containsAlkohol()
        {
           return true;
        }

        public bool containsGas()
        {
            return false;
        }

        public string Region { get; private set; }

        public Wine(string region)
        {
            Region = region;
        }

        public override string ToString()
        {
            return $"Region: {Region}";
        }
    }
}
