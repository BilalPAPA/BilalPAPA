﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlascheMitInhalt
{
  

    enum Volume
    {
        _250,
        _500,
        _1000,
        _2000
    }

    interface Liquid
    {
         bool containsAlkohol();

         bool containsGas();

    }

    class Bottle
    {
        //Liquid 
        public Liquid Liquid { get; private set; }

        public double CurrentVolume { get; private set; }

        public Volume MaxVolume { get; private set; }

        public bool isEmpty ()
        {
            bool antwort;
            if (CurrentVolume <= 0)
                antwort = true;
            else
                antwort = false;

            return antwort;

        }

        public void fillUp()
        {
            if (isEmpty())
            {
                this.Liquid = Liquid;

                CurrentVolume = (double)MaxVolume;
            }
            else
            {
                throw new ArgumentException("Die Flasche ist leer !!!");
            }
        }


        const int gulp = 50; 

        public void Drink (int sips)
        {
            sips *= gulp;
            CurrentVolume += sips;
        }


        public void Finish()
        {
            CurrentVolume = 0;
        }


        public Bottle(Liquid liquid, double currentVolume, Volume volume)
        {
            Liquid = liquid;
            CurrentVolume = currentVolume;
            MaxVolume = volume;
        }

        public override string ToString()
        {
            return $"Liquid: {Liquid} CurrentVolume {CurrentVolume} Volume: {MaxVolume}";
        }
    }
}
