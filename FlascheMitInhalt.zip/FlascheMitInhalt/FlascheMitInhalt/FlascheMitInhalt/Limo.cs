﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlascheMitInhalt
{
    class Limo : Liquid
    {
        bool Liquid.containsAlkohol()
        {
           return false;
        }

        bool Liquid.containsGas()
        {
            return true;
        }
    }
}
