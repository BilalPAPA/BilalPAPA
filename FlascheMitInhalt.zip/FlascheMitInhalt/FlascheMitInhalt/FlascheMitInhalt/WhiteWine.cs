﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlascheMitInhalt
{
    class WhiteWine : Wine
    {
        public WhiteWine(string region) 
            : base(region)
        {
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
