﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlascheMitInhalt
{
    class Beer : Liquid
    {
        public bool containsGas()
        {
            return true;
        }

        public bool containsAlkohol()
        {
            return true;
        }

        public string brewery { get; private set; }

        public Beer(string brewery)
        {
            this.brewery = brewery;
        }

        



        public override string ToString()
        {
            return $"Brewery: {brewery}";
        }
    }
}
